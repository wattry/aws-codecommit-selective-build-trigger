const AWS = require('aws-sdk');
const {
  basename,
  sep
} = require('path');

const EXTENSIONS = ["js"];
const FILENAMES = ["DockerFile", "Dockerfile"];
const {
  CODE_BUILD_PROJECT,
  ECR_REPO_NAME
} = process.env;

const codecommit = new AWS.CodeCommit();
const codebuild = new AWS.CodeBuild();

async function getLastCommitID(repositoryName, branchName = 'master') {
  const {
    branch: {
      commitId
    }
  } = await codecommit.getBranch({
    repositoryName,
    branchName
  }).promise();

  return commitId;
}

async function getLastCommitLog(repositoryName, commitId) {

  const {
    commit
  } = await codecommit.getCommit({
    repositoryName,
    commitId
  }).promise();

  return commit;
}

async function getFileDifferences(repositoryName, lastCommitID, previousCommitID) {

  const options = {
    repositoryName,
    afterCommitSpecifier: lastCommitID
  };

  if (previousCommitID) options.beforeCommitSpecifier = previousCommitID;

  const {
    differences = []
  } = await codecommit.getDifferences(options).promise();

  return differences;
}

exports.handler = async (event) => {
  try {
    const {
      Records: [{
        awsRegion,
        codecommit: {
          references: [{
            commit,
            commitHash = commit || getLastCommitID(repoName, branchName),
            ref,
            branchName = basename(ref)
          }]
        },
        eventSourceARN,
        repoName = eventSourceARN.split(':').pop(),
        accountId = eventSourceARN.split(':')[4]
      }]
    } = event;

    const { parents: [previousCommitID] } = await getLastCommitLog(repoName, commitHash);
    const differences = await getFileDifferences(repoName, commitHash, previousCommitID);
    const imagesToBuild = [];

    for (let i = 0; i < differences.length; i++) {
      const {
        afterBlob: {
          path,
          imageName = path.split(sep).shift(),
          file = basename(path).split('.')
        }
      } = differences[i];
      const [fileName, extension] = file;


      if (EXTENSIONS.includes(extension) || FILENAMES.includes(fileName)) {
        const buildOptions = {
          projectName: CODE_BUILD_PROJECT,
          sourceVersion: commitHash,
          sourceTypeOverride: 'CODECOMMIT',
          sourceLocationOverride: `https://git-codecommit.${awsRegion}.amazonaws.com/v1/repos/${repoName}`,
          environmentVariablesOverride: [
            {
              name: 'AWS_DEFAULT_REGION',
              value: awsRegion,
              type: 'PLAINTEXT'
            },
            {
              name: 'ECR_REPO',
              value: repoName,
              type: 'PLAINTEXT'
            }, {
              name: 'AWS_ACCOUNT_ID',
              value: accountId,
              type: 'PLAINTEXT'
            },
            {
              name: 'IMAGE_NAME',
              value: imageName,
              type: 'PLAINTEXT'
            },
            {
              name: 'BRANCH_NAME',
              value: branchName,
              type: 'PLAINTEXT'
            }
          ]
        };

        console.log(JSON.stringify('buildOptions', buildOptions));
        imagesToBuild.push(
          codebuild.startBuild(buildOptions).promise()
            .then(response => ({
              imageName,
              response
            }))
            .catch(error => ({
              imageName,
              error
            }))
        );
      }
    }

    const images = await Promise.allSettled(imagesToBuild);
    const rejectedBuild = false;

    images.forEach(({ value: { imageName }}, i) => {
      if (error) {
        console.error('An error occurred building image', imageName);
        rejectedBuild = true;
      } else {
        console.info(imageName, ' built');
      }
    });

    if (rejectedBuild) {
      throw new Error('An image failed to build. Please check the build logs and try again');
    }

    return 'Success';
  } catch (error) {
    console.error('An error occurred building images');
  }
};